/*
	Milyn - Copyright (C) 2006

	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License (version 2.1) as published by the Free Software
	Foundation.

	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	See the GNU Lesser General Public License for more details:
	http://www.gnu.org/licenses/lgpl.txt
*/
package org.smooks.csv;

import org.milyn.csv.prog.CSVListBinder;
import org.milyn.csv.prog.CSVMapBinder;
import org.xml.sax.SAXException;
import org.smooks.csv.model.Person;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @author <a href="mailto:tom.fennelly@jboss.com">tom.fennelly@jboss.com</a>
 */
public class SmooksProgrammaticRunner2 {

    public static void main(String[] args) throws IOException, SAXException {

        CSVListBinder listBinder = new CSVListBinder("firstName,lastName,gender,age,country", Person.class);

        List<Person> people = listBinder.bind(SmooksRunner.class.getResourceAsStream("input-message.csv"));

        System.out.println(people);        
    }

    public static void main2(String[] args) throws IOException, SAXException {

        CSVMapBinder listBinder = new CSVMapBinder("firstName,lastName,gender,age,country", Person.class, "firstName");

        Map<String, Person> people = listBinder.bind(SmooksRunner.class.getResourceAsStream("input-message.csv"));

        System.out.println(people.get("Mike"));
    }
}