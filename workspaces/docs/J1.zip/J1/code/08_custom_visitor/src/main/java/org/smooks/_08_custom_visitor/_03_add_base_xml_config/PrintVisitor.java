/*
	Milyn - Copyright (C) 2006

	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License (version 2.1) as published by the Free Software
	Foundation.

	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	See the GNU Lesser General Public License for more details:
	http://www.gnu.org/licenses/lgpl.txt
*/
package org.smooks._08_custom_visitor._03_add_base_xml_config;

import org.milyn.delivery.sax.*;
import org.milyn.container.ExecutionContext;
import org.milyn.SmooksException;
import org.milyn.cdr.annotation.ConfigParam;

import java.io.IOException;

/**
 * Configured PrintVisitor implementation.
 *
 * @author <a href="mailto:tom.fennelly@gmail.com">tom.fennelly@gmail.com</a>
 */
public class PrintVisitor implements SAXVisitBefore, SAXVisitAfter {

    private String beforeText;
    private String afterText;

    public void visitBefore(SAXElement saxElement, ExecutionContext executionContext) throws SmooksException, IOException {
        saxElement.getWriter(this).write(beforeText);
    }

    public void visitAfter(SAXElement saxElement, ExecutionContext executionContext) throws SmooksException, IOException {
        saxElement.getWriter(this).write(afterText);
    }

    @ConfigParam
    public PrintVisitor setBeforeText(String beforeText) {
        this.beforeText = beforeText;
        return this;
    }

    @ConfigParam
    public PrintVisitor setAfterText(String afterText) {
        this.afterText = afterText;
        return this;
    }
}