lesson_02 - add_programmatic_config
===================================
The code in this lesson demonstrates how to add programmatic configuration to the basic PrintVisitor implementation.