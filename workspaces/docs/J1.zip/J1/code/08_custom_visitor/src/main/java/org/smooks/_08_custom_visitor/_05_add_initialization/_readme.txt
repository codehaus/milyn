lesson_02 - add_initialization
==============================
The code in this lesson demonstrates how to add initialization logic to the PrintVisitor implementation.