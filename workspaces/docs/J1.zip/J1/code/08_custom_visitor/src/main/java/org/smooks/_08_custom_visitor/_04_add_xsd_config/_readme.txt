lesson_02 - add_xsd_config
==========================
The code in this lesson demonstrates how to add XSD based XML configuration to the basic PrintVisitor implementation.