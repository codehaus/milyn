lesson_02 - add_visit_lifecycle
===============================
The code in this lesson demonstrates how to add visit lifecycle logic to the PrintVisitor implementation.