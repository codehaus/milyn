lesson_02 - basic_impl
======================
The code in this lesson demonstrates the very basics of creating a SAX based Visitor implementation.