lesson_02 - add_base_xml_config
===============================
The code in this lesson demonstrates how to add base XML configuration to the basic PrintVisitor implementation.