/*
	Milyn - Copyright (C) 2006

	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License (version 2.1) as published by the Free Software
	Foundation.

	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	See the GNU Lesser General Public License for more details:
	http://www.gnu.org/licenses/lgpl.txt
*/
package org.smooks._08_custom_visitor._02_add_programmatic_config;

import org.milyn.Smooks;

import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;

/**
 * @author <a href="mailto:tom.fennelly@gmail.com">tom.fennelly@gmail.com</a>
 */
public class Run {

    public static void main(String[] args) {
        Smooks smooks = new Smooks();

        try {
            // Run with the following lines commented out... then run with them uncommented out...
            //smooks.addVisitor(new PrintVisitor().setBeforeText("[[[").setChildText("@@@").setAfterText("]]]"), "order");
            //smooks.addVisitor(new PrintVisitor().setBeforeText("(((").setChildText("+++").setAfterText(")))"), "order-item");

            smooks.filterSource(new StreamSource(Run.class.getResourceAsStream("/order-sample-message.xml")), new StreamResult(System.out));
        } finally {
            smooks.close();
        }
    }
}