package org.smooks.edi.model;

import java.math.BigDecimal;
import java.util.Date;

public class Header{
	String orderId;
	String statusCode;
	BigDecimal netAmount;
	BigDecimal totalAmount;
	BigDecimal tax;
	Date date;
	CustomerDetails customerDetails;

	public String getOrderId(){
		return this.orderId;
	}

	public void setOrderId(String orderId){
		this.orderId = orderId;
	}

	public String getStatusCode(){
		return this.statusCode;
	}

	public void setStatusCode(String statusCode){
		this.statusCode = statusCode;
	}

	public BigDecimal getNetAmount(){
		return this.netAmount;
	}

	public void setNetAmount(BigDecimal netAmount){
		this.netAmount = netAmount;
	}

	public BigDecimal getTotalAmount(){
		return this.totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount){
		this.totalAmount = totalAmount;
	}

	public BigDecimal getTax(){
		return this.tax;
	}

	public void setTax(BigDecimal tax){
		this.tax = tax;
	}

	public Date getDate(){
		return this.date;
	}

	public void setDate(Date date){
		this.date = date;
	}

	public CustomerDetails getCustomerDetails(){
		return this.customerDetails;
	}

	public void setCustomerDetails(CustomerDetails customerDetails){
		this.customerDetails = customerDetails;
	}

}