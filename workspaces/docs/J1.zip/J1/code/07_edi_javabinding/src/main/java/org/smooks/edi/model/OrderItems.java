package org.smooks.edi.model;

import java.util.List;
import java.util.ArrayList;

public class OrderItems{
	List<OrderItem> orderItems;

	public List<OrderItem> getOrderItems(){
		if (orderItems == null) {
			this.orderItems = new ArrayList<OrderItem>();
		}
		return this.orderItems;
	}

	public void setOrderItems(List<OrderItem> orderItems){
		this.orderItems = orderItems;
	}

}