package org.smooks.edi.model;

import java.math.BigDecimal;
import java.lang.Long;
import java.lang.Integer;

public class OrderItem{
	Integer position;
	Long quantity;
	String productId;
	String title;
	BigDecimal price;

	public Integer getPosition(){
		return this.position;
	}

	public void setPosition(Integer position){
		this.position = position;
	}

	public Long getQuantity(){
		return this.quantity;
	}

	public void setQuantity(Long quantity){
		this.quantity = quantity;
	}

	public String getProductId(){
		return this.productId;
	}

	public void setProductId(String productId){
		this.productId = productId;
	}

	public String getTitle(){
		return this.title;
	}

	public void setTitle(String title){
		this.title = title;
	}

	public BigDecimal getPrice(){
		return this.price;
	}

	public void setPrice(BigDecimal price){
		this.price = price;
	}

}