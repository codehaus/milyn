package org.smooks.edi.model;


public class CustomerDetails{
	String username;
	Name name;
	String state;
	String email;

	public String getUsername(){
		return this.username;
	}

	public void setUsername(String username){
		this.username = username;
	}

	public Name getName(){
		return this.name;
	}

	public void setName(Name name){
		this.name = name;
	}

	public String getState(){
		return this.state;
	}

	public void setState(String state){
		this.state = state;
	}

	public String getEmail(){
		return this.email;
	}

	public void setEmail(String email){
		this.email = email;
	}

}