package org.smooks.edi;

import org.smooks.edi.model.OrderFactory;
import org.smooks.edi.model.Order;
import org.smooks.edi.model.OrderItem;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * @author <a href="mailto:tom.fennelly@jboss.com">tom.fennelly@jboss.com</a>
 */
public class FactoryRunner1 {

    public static void main(String[] args) throws IOException, SAXException {
        OrderFactory factory = OrderFactory.getInstance();

        InputStream ediStream = FactoryRunner1.class.getResourceAsStream("input-message.edi");
        Order order = factory.parse(ediStream);

        print(order);
    }

    private static void print(Order order) {
        System.out.println();
        System.out.println("First Name: " + order.getHeader().getCustomerDetails().getName().getFirstname());
        System.out.println("Date:       " + order.getHeader().getDate());
        System.out.println("Email:      " + order.getHeader().getCustomerDetails().getEmail());

        System.out.println("");
        System.out.println("Order Items: ");
        List<OrderItem> orderItems = order.getOrderItems().getOrderItems();
        for(int i = 0; i < orderItems.size(); i++) {
            OrderItem orderItem = orderItems.get(i);
            System.out.println("\t(" + i + ")");
            System.out.println("\tProduct ID:    " + orderItem.getProductId());
            System.out.println("\tProduct Title: " + orderItem.getTitle());
            System.out.println("\tQuantity:      " + orderItem.getQuantity());
            System.out.println("\tPrice:         " + orderItem.getPrice());
        }
    }
}