package org.smooks.edi.model;

import org.milyn.Smooks;
import org.milyn.payload.JavaResult;
import org.xml.sax.SAXException;

import javax.xml.transform.stream.StreamSource;
import java.io.Reader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.IOException;
import javax.xml.transform.Result;

public class OrderFactory {

    private Smooks smooks;

    public static OrderFactory getInstance() throws IOException, SAXException {
        return new OrderFactory();
    }

    public void addConfigurations(InputStream resourceConfigStream) throws SAXException, IOException {
        smooks.addConfigurations(resourceConfigStream);
    }

    public Order parse(InputStream ediStream, Result... additionalResults) {
        return parse(new InputStreamReader(ediStream), additionalResults);
    }

    public Order parse(Reader ediStream) {
        JavaResult result = new JavaResult();
        smooks.filterSource(new StreamSource(ediStream), result);
        return (Order) result.getBean("order");
    }

    public Order parse(Reader ediStream, Result... additionalResults) {
        JavaResult javaResult = new JavaResult();
        int numAdditionalRes = (additionalResults != null? additionalResults.length : 0);
        Result[] results = new Result[numAdditionalRes + 1];
        
        results[0] = javaResult;
        if(additionalResults != null) {
            System.arraycopy(additionalResults, 0, results, 1, numAdditionalRes);
        }
        
        smooks.filterSource(new StreamSource(ediStream), results);
        return (Order) javaResult.getBean("order");
    }

    private OrderFactory() throws IOException, SAXException {
        smooks = new Smooks(OrderFactory.class.getResourceAsStream("bindingconfig.xml"));
    }

}