package org.smooks.edi.model;


public class Order{
	Header header;
	OrderItems orderItems;

	public Header getHeader(){
		return this.header;
	}

	public void setHeader(Header header){
		this.header = header;
	}

	public OrderItems getOrderItems(){
		return this.orderItems;
	}

	public void setOrderItems(OrderItems orderItems){
		this.orderItems = orderItems;
	}

}