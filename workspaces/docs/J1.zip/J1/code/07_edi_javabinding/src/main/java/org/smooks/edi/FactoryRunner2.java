package org.smooks.edi;

//import org.smooks.edi.model.OrderFactory;
//import org.smooks.edi.model.Order;
//import org.smooks.edi.model.OrderItem;
import org.xml.sax.SAXException;

import java.io.IOException;

/**
 * @author <a href="mailto:tom.fennelly@jboss.com">tom.fennelly@jboss.com</a>
 */
public class FactoryRunner2 {

    public static void main(String[] args) throws IOException, SAXException {
//        OrderFactory factory = OrderFactory.getInstance();
//
//        factory.addConfigurations(FactoryRunner2.class.getResourceAsStream("validation-config.xml"));
//
//        InputStream ediStream = FactoryRunner2.class.getResourceAsStream("input-message.edi");
//        ValidationResult validationResult = new ValidationResult();
//        factory.parse(ediStream, new StreamResult(System.out), validationResult);
//
//        System.out.println("");
//        System.out.println("");
//        System.out.println(validationResult);
    }
}