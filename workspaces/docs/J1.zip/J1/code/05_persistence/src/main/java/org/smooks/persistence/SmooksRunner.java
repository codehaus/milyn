package org.smooks.persistence;

import org.milyn.Smooks;
import org.milyn.scribe.adapter.jpa.EntityManagerRegister;
import org.milyn.persistence.util.PersistenceUtil;
import org.milyn.container.ExecutionContext;
import org.xml.sax.SAXException;

import javax.xml.transform.stream.StreamSource;
import javax.persistence.Persistence;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import java.io.IOException;

/**
 * @author <a href="mailto:tom.fennelly@jboss.com">tom.fennelly@jboss.com</a>
 */
public class SmooksRunner {

    public static void main(String[] args) throws IOException, SAXException {

        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("db");

        try {
            EntityManager entityManager = entityManagerFactory.createEntityManager();

            try {
                Smooks smooks = new Smooks(SmooksRunner.class.getResourceAsStream("smooks-config.xml"));

                try {
                    ExecutionContext executionContext = smooks.createExecutionContext();

                    PersistenceUtil.setDAORegister(executionContext, new EntityManagerRegister(entityManager));

                    EntityTransaction tx = entityManager.getTransaction();
                    tx.begin();
                    try {
                        smooks.filterSource(executionContext, new StreamSource(SmooksRunner.class.getResourceAsStream("order.xml")));
                        tx.commit();
                    } catch (Exception e){
                        tx.rollback();
                    }
                } finally {
                    smooks.close();
                }
            } finally {
                entityManager.close();
            }
        } finally {
            entityManagerFactory.close();
        }
    }

}