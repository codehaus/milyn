package org.smooks.xml;

import org.milyn.Smooks;
import org.milyn.payload.JavaResult;
import org.smooks.xml.model.Order;
import org.xml.sax.SAXException;

import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author <a href="mailto:tom.fennelly@jboss.com">tom.fennelly@jboss.com</a>
 */
public class SmooksRunner {

    public static void main(String[] args) throws IOException, SAXException {

        InputStream orderStream = SmooksRunner.class.getResourceAsStream("order.xml");
        Smooks smooks = new Smooks(SmooksRunner.class.getResourceAsStream("smooks-config-2.xml"));

        JavaResult javaResult = new JavaResult();
        try {
            smooks.filterSource(new StreamSource(orderStream), javaResult);
        } finally {
            smooks.close();
        }

        Order order = (Order) javaResult.getBean("order");

        System.out.println(order);
    }

}
