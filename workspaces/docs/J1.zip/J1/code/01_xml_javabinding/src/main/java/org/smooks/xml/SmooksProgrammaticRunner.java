package org.smooks.xml;

import org.milyn.Smooks;
import org.milyn.javabean.Bean;
import org.milyn.payload.JavaResult;
import org.smooks.xml.model.OrderItem;
import org.smooks.xml.model.Order;
import org.smooks.xml.model.Header;
import org.xml.sax.SAXException;

import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.util.ArrayList;

/**
 * @author <a href="mailto:tom.fennelly@jboss.com">tom.fennelly@jboss.com</a>
 */
public class SmooksProgrammaticRunner {

    public static void main(String[] args) throws IOException, SAXException {

        Smooks smooks = new Smooks(); // No XML config!!

        // Programmatically create the binding config and add it to the Smooks instance...
        Bean orderBean = new Bean(Order.class, "order")
                         .bindTo("header", new Bean(Header.class, "header")
                             .bindTo("orderId", "order/@id")
                             .bindTo("customerNumber", "header/customer/@number")
                             .bindTo("customerName", "header/customer"))
                         .bindTo("orderItems", new Bean(ArrayList.class, "orderItems")
                             .bindTo("orderItem", new Bean(OrderItem.class, "orderItem", "order-item")
                                 .bindTo("productId", "order-item/product")
                                 .bindTo("quantity", "order-item/quantity")
                                 .bindTo("price", "order-item/price")));
        smooks.addVisitor(orderBean);

        JavaResult javaResult = new JavaResult();

        try {
            smooks.filterSource(new StreamSource(SmooksProgrammaticRunner.class.getResourceAsStream("order.xml")),
                                javaResult);
        } finally {
            smooks.close();
        }

        Order order = (Order) javaResult.getBean("order");

        System.out.println(order);
    }

}