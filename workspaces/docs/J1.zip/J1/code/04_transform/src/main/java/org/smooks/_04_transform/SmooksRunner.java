package org.smooks._04_transform;

import org.milyn.Smooks;
import org.xml.sax.SAXException;

import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;

/**
 * @author <a href="mailto:tom.fennelly@jboss.com">tom.fennelly@jboss.com</a>
 */
public class SmooksRunner {

    public static void main(String[] args) throws IOException, SAXException {

        //Smooks smooks = new Smooks(SmooksRunner.class.getResourceAsStream("reader-config.xml"));
        Smooks smooks = new Smooks(SmooksRunner.class.getResourceAsStream("transform-config.xml"));

        try {
            System.out.println();

            smooks.filterSource(new StreamSource(SmooksRunner.class.getResourceAsStream("input-message.csv")),
                                new StreamResult(System.out));

            System.out.println();
        } finally {
            smooks.close();
        }
    }
}