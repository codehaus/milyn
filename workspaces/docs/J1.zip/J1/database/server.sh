java -classpath hsqldb.jar org.hsqldb.Server -database db
